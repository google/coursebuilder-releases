gcb-md-header: /md_header.html
gcb-md-footer: /md_footer.html

# Welcome to Course Builder Markdown!

Learn about Markdown in Course Builder Web Server [here](markdown.html):